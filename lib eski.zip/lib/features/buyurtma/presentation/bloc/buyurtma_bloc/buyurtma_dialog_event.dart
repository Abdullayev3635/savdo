part of 'buyurtma_dialog_bloc.dart';

@immutable
abstract class BuyurtmaDialogEvent {}

class BuyurtmaInitialEvent extends BuyurtmaDialogEvent {}

class BuyurtmaInitialLocalEvent extends BuyurtmaDialogEvent {}
