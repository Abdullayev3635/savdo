part of 'archive_bloc.dart';

@immutable
abstract class ArchiveEvent {}

class GetArchiveEvent extends ArchiveEvent {}
