package com.example.savdo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
